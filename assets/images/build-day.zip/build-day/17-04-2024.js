// // F =  (C × 9/5) + 32

// // convert 11 degeree celcius to F
// // let C = 11
// // therefore F = (11 * 9/5) + 32 = 51.8F

// const fahrenheitToCel = (celsius) => {
//   const fahrenheit = (celsius * 9) / 5 + 32;
//   return fahrenheit;
// };

// const firstFahrenheit = fahrenheitToCel(11);
// console.log(firstFahrenheit);

// function fahrenheitToCel(celsius) {
//   const fahrenheit = (celsius * 9) / 5 + 32;
//   return fahrenheit;
// }

// const number = [2, 3, 5, 6, 7];

// const highNumbers = number
//   .filter((value) => value > 5)
//   .map((value) => value * 2);

// console.log(highNumbers);

// function  square(fn, number =2) {
//    return fn(number) 
// }

// function sqFn(number) {
//     return number ** 2
// }

// const squareNumber = square(sqFn, 3)
// console.log(squareNumber)

// perimeter of rectangle = 2(length + breadth)
// // Area of rectangle = length * breadth

function perimeterOfRectangle(length, breadth) {
    return 2 * (length + breadth)
}

const perimeter = perimeterOfRectangle(10, 7)
console.log("perimeter",perimeter)


// perimeter of rectangle = 2(length + breadth)
// let length = 10, breadth = 7
// perimeter = 2 * (10 + 7)


// array of positive numbers e.g [2,4 ,6]
// return a new array of each item divided by 2 e.g [0, 1, 3]

// array.map(value => return value/2)

function divideArray(arrayOfNumbers) {
    const positive = arrayOfNumbers.map(value => value / 2)
    return positive
}

// numbers = [2, 4. 6], [4,6]
console.log(divideArray([2,4,6]))
// filteredArray([2,4,6])
// return [4,6]

function filteredArray(arrayOfNumbers=[3,6,9,7,1]) {
    const positive = arrayOfNumbers.filter(value => value > 2)
    return positive
}

console.log(filteredArray())