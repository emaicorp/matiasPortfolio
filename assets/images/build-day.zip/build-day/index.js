// const toyotaCarObject = {
//     carName:"Toyota",
//     color:"blue",
//     getCarName: function () {
//         console.log(this.carName)
//     },
//     changeCarColor: function(color) {
//         this.color = color
//     },
// }

// const benzCarObject = {
//     carName:"Benz",
//     color:"white",
//     getCarName: function () {
//         console.log(this.carName)
//     },
//     changeCarColor: function(color) {
//         this.color = color
//     },
// }

const { Car } = require("./carClass")
const {Calculate} = require('./calculate')

const benzCar = new Car("Benz", "black","2024","sedan")
const fordCar = new Car("Ford", "white","2027","suv")

const calc = new Calculate(10,20)

console.log(calc.add())
console.log(calc.subtract())



// console.log(benzCar.getCarAttributes())
// console.log(fordCar.getCarAttributes())


// fordCar.changeCarColor("red")
// console.log(fordCar.getCarAttributes())

function addDivide (a, b){
    return calc.add()/2
}


// function changeAnyCarColor(carObject = toyotaCarObject, newColor = "pink") {
//   carObject.changeCarColor(newColor);
//   return carObject;
// }



// console.log(changeAnyCarColor())
// carObject = toyotaCarObject
// newColor = "pink"
// carObject.changeAnyCarColor(newColor)
// return carObject

// console.log(changeAnyCarColor(toyotaCarObject, "orange"));
// console.log(changeAnyCarColor(toyotaCarObject, "green"));

// console.log(changeAnyCarColor(benzCarObject, "pink"));
// console.log(changeAnyCarColor(benzCarObject, "orange"));
// console.log(changeAnyCarColor(benzCarObject, "green"));

// function wearBag(bag) {
//   console.log("i don wear bag o", bag);
// }

// wearBag("black bag");

// console.log("initial color",carObject.color)
// carObject.changeCarColor("yellow")
// console.log("after color",carObject.color)

// let a = 10
// let b = 20

// function showA (){
//     let a = 60
//     console.log(a)
// }
// function showB (){
//    let b = 10
//     if (b === 10){
//         b = 600
//         console.log(b)
//     }
// }

// showA()
// showB ()
// console.log(a)
