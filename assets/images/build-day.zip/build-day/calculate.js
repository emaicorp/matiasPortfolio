class Calculate {
  constructor(a, b) {
    this.a = a;
    this.b = b;
  }

  add() {
    return this.a + this.b;
  }

  subtract() {
    if (this.a > this.b) return this.a - this.b;
    return this.b - this.a;
    // return this.a > this.b ? this.a - this.b : this.b - this.a
  }


}


module.exports = {
    Calculate
}
