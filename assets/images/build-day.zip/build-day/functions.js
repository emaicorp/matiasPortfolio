// let a;
// a = 10
// let num1, num2;



function add(num1, num2){
   const addedNumber = num1 + num2
   return addedNumber
}


const sumAdd = add(10, 20)

//  °F = (°C × 9/5) + 32

function FahrenheitCel(celcius){
    return (celcius * 9/5) + 32
}

// if celcius = 32
// F = (32 * 9/5) + 32 = 89.6

// f = number1 = num2



function checkEqual(num1, num2) {
    return num1 === num2
}


const fahrenthiet = FahrenheitCel(32)
console.log("fahrenhiet",fahrenthiet)




// f = checkNumber(13, 0, numbers)
// f = checkNumber(5, 1, numbers)
// f = checkNumber(6, 2, numbers)
// const numbers = [13, 5,6,25, 29, 30]

// foundNumber = numbers.findLast(checkNumber)
// console.log(foundNumber)


function checkNumber(value, index, array) {
    // if (value > 30){
    //     console.log("found you")
    //     return value > 30
    // }
    let condition = value > 18
    return condition
}

// numbers[0] > 18
// console.log(checkNumber(3, numbers))

const numbers = [45, 4, 9, 16, 25];
let sum = 1;
numbers.forEach(myFunction);

function myFunction(value, index, array) {
  sum *= value
}

// txt = 45<br>
// txt = 45<br>4<br>9<br>16<br>25<br>

const newNumbers = numbers.map(function (value) {
    return value * 2
})

console.log(newNumbers)

const filteredArray = numbers.filter((value) => {
    return value > 12;
})

// console.log(filteredArray)
function myFunction(value, index, array) {
    return value * 2
}

const myFunction = (value, index, array) =>{

}

let voteable;
const age = 17

if (age < 18 ) {
    voteable = "too Young to vote"
}
else {
    voteable = "Old enough"
}

// let voteable = (age < 18) ? "Too young":"Old enough";





