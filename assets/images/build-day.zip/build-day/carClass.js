class Car {
  constructor(carName, carColor, carModel, carType) {
    this.name = carName;
    this.color = carColor;
    this.model = carModel;
    this.type = carType;
  }





  getCarName() {
    return this.name;
  }

  changeCarColor(newColor) {
    this.color = newColor;
    return;
  }

  getCarAttributes() {
    return `${this.name} ${this.color} ${this.model} ${this.type}`;
  }


  changeCarType (newType){
    this.type = newType
  }
}

module.exports = {
  Car,
};
